﻿namespace Noef
{
	public enum DbType
	{
		SqlServer2012, // I'm putting this in here prematurely, because 2012 has some awesome new paging features that make things really easy
		SqlServer,
		SqlCE
	}
}
