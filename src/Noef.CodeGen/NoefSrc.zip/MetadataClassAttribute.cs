﻿using System;

namespace Noef
{
	[AttributeUsage(AttributeTargets.Class)]
	public class MetadataClassAttribute : Attribute
	{
	}
}
